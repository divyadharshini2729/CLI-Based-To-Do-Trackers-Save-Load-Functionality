from task_manager import TaskManager

tm = TaskManager("tasks.json")

def view_tasks():
    tasks = tm.get_all_tasks()
    if not tasks:
        print("📋 No tasks available!")
        return
    print("\n📋 Current Tasks:")
    for t in tasks:
        status = "✅" if t["status"] == "Completed" else "❌"
        print(f"{t['id']}. {status} {t['description']}")

def main():
    while True:
        print("\n====== 🧠 TO-DO TRACKER MENU ======")
        print("1️⃣  Add Task")
        print("2️⃣  View Tasks")
        print("3️⃣  Edit Task")
        print("4️⃣  Delete Task")
        print("5️⃣  Toggle Complete/Incomplete")
        print("6️⃣  Save Tasks")
        print("7️⃣  Exit")
        choice = input("Choose an option (1-7): ")

        if choice == "1":
            desc = input("Enter task description: ")
            tm.add_task(desc)
            print("✅ Task added!")
            view_tasks()  # Show all tasks

        elif choice == "2":
            view_tasks()  # Just view tasks

        elif choice == "3":
            view_tasks()
            try:
                tid = int(input("Enter task ID to edit: "))
                new_desc = input("Enter new description: ")
                tm.edit_task(tid, new_desc)
                print("✏️ Task updated!")
                view_tasks()
            except:
                print("⚠️ Invalid input")

        elif choice == "4":
            view_tasks()
            try:
                tid = int(input("Enter task ID to delete: "))
                tm.delete_task(tid)
                print("🗑️ Task deleted!")
                view_tasks()
            except:
                print("⚠️ Invalid input")

        elif choice == "5":
            view_tasks()
            try:
                tid = int(input("Enter task ID to toggle status: "))
                tm.toggle_task_status(tid)
                print("🔄 Status updated!")
                view_tasks()
            except:
                print("⚠️ Invalid input")

        elif choice == "6":
            tm.get_all_tasks()  # Just ensure tasks are loaded
            print("💾 Tasks saved!")  # TaskManager automatically saves after each operation
            view_tasks()

        elif choice == "7":
            print("👋 Exiting...")
            break

        else:
            print("⚠️ Invalid choice")

if __name__ == "__main__":
    main()
