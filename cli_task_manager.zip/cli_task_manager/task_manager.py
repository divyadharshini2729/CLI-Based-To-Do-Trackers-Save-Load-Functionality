import json
import os

class TaskManager:
    def __init__(self, storage_path="tasks.json"):
        self.storage_path = storage_path
        os.makedirs(os.path.dirname(self.storage_path) if os.path.dirname(self.storage_path) else ".", exist_ok=True)
        if not os.path.exists(self.storage_path):
            with open(self.storage_path, 'w') as f:
                json.dump([], f)

    def get_all_tasks(self):
        with open(self.storage_path, 'r') as f:
            return json.load(f)

    def add_task(self, description):
        tasks = self.get_all_tasks()
        task_id = len(tasks) + 1
        tasks.append({"id": task_id, "description": description, "status": "Incomplete"})
        self.save_tasks(tasks)

    def delete_task(self, task_id):
        tasks = self.get_all_tasks()
        tasks = [t for t in tasks if t["id"] != task_id]
        for i, t in enumerate(tasks):
            t["id"] = i + 1
        self.save_tasks(tasks)

    def edit_task(self, task_id, new_desc):
        tasks = self.get_all_tasks()
        for task in tasks:
            if task["id"] == task_id:
                task["description"] = new_desc
        self.save_tasks(tasks)

    def toggle_task_status(self, task_id):
        tasks = self.get_all_tasks()
        for task in tasks:
            if task["id"] == task_id:
                task["status"] = "Completed" if task["status"] == "Incomplete" else "Incomplete"
        self.save_tasks(tasks)

    def save_tasks(self, tasks):
        with open(self.storage_path, 'w') as f:
            json.dump(tasks, f, indent=4)
