from flask import Flask, request, render_template_string
from task_manager import TaskManager

app = Flask(__name__)
tm = TaskManager("tasks.json")

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<title>To-Do Tracker</title>
<style>
body{font-family:Arial;padding:30px;background:#f2f2f2;}
h1{color:#333;}
input[type=text]{padding:8px;width:250px;}
button{padding:8px 12px;margin:5px;background:#007bff;color:white;border:none;border-radius:5px;cursor:pointer;}
button:hover{background:#0056b3;}
ul{background:white;padding:15px;border-radius:8px;list-style:none;}
li{padding:4px 0;}
</style>
</head>
<body>
<h1>📝 To-Do Tracker</h1>
<form method="POST" action="/add">
<input type="text" name="description" placeholder="Enter task" required>
<button type="submit">Add</button>
</form>

<ul>
{% for t in tasks %}
<li>
{{ t.id }}. {% if t.status=="Completed" %}✅{% else %}❌{% endif %} {{ t.description }}
<form method="POST" action="/toggle/{{ t.id }}" style="display:inline;">
<button type="submit">Toggle</button>
</form>
<form method="POST" action="/delete/{{ t.id }}" style="display:inline;">
<button type="submit" style="background:red;">Delete</button>
</form>
<form method="POST" action="/edit/{{ t.id }}" style="display:inline;">
<input type="text" name="new_desc" placeholder="Edit">
<button type="submit">Edit</button>
</form>
</li>
{% endfor %}
</ul>
</body>
</html>
"""

@app.route('/')
def home():
    tasks = tm.get_all_tasks()
    return render_template_string(HTML_TEMPLATE, tasks=tasks)

@app.route('/add', methods=['POST'])
def add_task():
    desc = request.form.get("description")
    if desc:
        tm.add_task(desc)
    return home()

@app.route('/delete/<int:task_id>', methods=['POST'])
def delete(task_id):
    tm.delete_task(task_id)
    return home()

@app.route('/toggle/<int:task_id>', methods=['POST'])
def toggle(task_id):
    tm.toggle_task_status(task_id)
    return home()

@app.route('/edit/<int:task_id>', methods=['POST'])
def edit(task_id):
    new_desc = request.form.get("new_desc")
    if new_desc:
        tm.edit_task(task_id, new_desc)
    return home()

if __name__ == '__main__':
    print("✅ Flask server running at http://127.0.0.1:5000")
    app.run(debug=True)
